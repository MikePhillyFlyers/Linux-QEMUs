sudo mount -o loop,offset=0x100000 image_mips64.raw out/
echo "Mounted to out/"
