#!/bin/sh
qemu-system-arm -m 256M -M versatilepb -kernel zImage_2.6.32.21 -serial stdio -display none -append "root=/dev/sda1 earlycon earlyprintk console=ttyAMA0" -drive if=scsi,file=image_arm32.raw,format=raw
