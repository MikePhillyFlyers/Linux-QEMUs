

login
-------

user:  root
pwd:   root

ip address:  192.168.1.3


(ssh, gdb, gdbserver, tcpdump, netcat, socat, iptables, and others are installed in this rootfs)


OPTIONS TO RUN IT:
====================


RUN_ME.sh  -->  normal run

RUN_DBG.sh -->  qemu starts up in debug mode, waits for local GDB connection to 127.0.0.1:1234
