#!/bin/bash

set -u

IID=1

TAPDEV_0=tap${IID}_0
TAPDEV_1=tap${IID}_1
HOSTNETDEV_0=${TAPDEV_0}
HOSTNETDEV_1=${TAPDEV_1}

echo "creating TAP device..."
sudo tunctl -t ${TAPDEV_0} -u ${USER}
sudo tunctl -t ${TAPDEV_1} -u ${USER}


echo "Bringing up TAP device..."
sudo ip link set ${HOSTNETDEV_0} up
sudo ip addr add 192.168.1.2/24 dev ${HOSTNETDEV_0}


echo "Adding route to 192.168.1.3..."
sudo ip route add 192.168.1.3 via 192.168.1.3 dev ${HOSTNETDEV_0}


function cleanup
{

echo "Deleting route..."
sudo ip route flush dev ${HOSTNETDEV_0}
sudo ip route flush dev ${HOSTNETDEV_1}

echo "deleting tap"
sudo ip link set ${TAPDEV_0} down
sudo ip link set ${TAPDEV_1} down

sudo tunctl -d ${TAPDEV_0}
sudo tunctl -d ${TAPDEV_1}

}


trap cleanup EXIT

echo "Starting firmware emulation... use Ctrl-a + x to exit (or Ctrl-C)"
sleep 1s

QEMU_AUDIO_DRV=none qemu-system-mips64 -m 2G -M malta -kernel vmlinux_2.6.32.21 \
         -drive if=ide,file=image_mips64.raw,format=raw,id=rootfs \
	 -append "rw root=/dev/hda1 init=/sbin/init" \
         -device e1000,netdev=net0 -netdev tap,id=net0,ifname=${TAPDEV_0},script=no \
	 -serial stdio \
	 -display none \
         -s \
         -S

